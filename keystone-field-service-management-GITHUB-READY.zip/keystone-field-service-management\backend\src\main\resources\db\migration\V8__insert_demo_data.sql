-- ============================================================================
-- V8__insert_demo_data.sql
--
-- Inserts demo data for testing the Keystone application
-- ============================================================================

-- Insert demo users (passwords are BCrypt hashed for "password123")
INSERT INTO users (id, first_name, last_name, email, password, phone_number, role, active, created_at, updated_at) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'Admin', 'User', 'admin@keystone.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+1234567890', 'ADMIN', true, NOW(), NOW()),
('550e8400-e29b-41d4-a716-446655440002', 'Manager', 'User', 'manager@keystone.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+1234567891', 'MANAGER', true, NOW(), NOW()),
('550e8400-e29b-41d4-a716-446655440003', 'Dispatcher', 'User', 'dispatcher@keystone.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+1234567892', 'DISPATCHER', true, NOW(), NOW()),
('550e8400-e29b-41d4-a716-446655440004', 'John', 'Technician', 'technician@keystone.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+1234567893', 'TECHNICIAN', true, NOW(), NOW()),
('550e8400-e29b-41d4-a716-446655440005', 'Jane', 'Worker', 'worker@keystone.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+1234567894', 'WORKER', true, NOW(), NOW()),
('550e8400-e29b-41d4-a716-446655440006', 'Customer', 'One', 'customer@keystone.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', '+1234567895', 'CUSTOMER', true, NOW(), NOW());

-- Insert demo customers
INSERT INTO customers (id, customer_code, company_name, contact_person, email, phone_number, address_line1, address_line2, city, state, postal_code, country, active, created_at, updated_at) VALUES
('660e8400-e29b-41d4-a716-446655440001', 'CUST001', 'Acme Corporation', 'John Smith', 'john@acme.com', '+1234567890', '123 Main St', 'Suite 100', 'San Francisco', 'CA', '94102', 'USA', true, NOW(), NOW()),
('660e8400-e29b-41d4-a716-446655440002', 'CUST002', 'Tech Solutions Inc', 'Jane Doe', 'jane@techsolutions.com', '+1234567891', '456 Oak Ave', '', 'Oakland', 'CA', '94601', 'USA', true, NOW(), NOW());

-- Insert demo sites
INSERT INTO sites (id, name, address, customer_id, city, state, postal_code, country, status, created_at, updated_at) VALUES
('770e8400-e29b-41d4-a716-446655440001', 'Acme Data Center', '123 Main St, Suite 100', '660e8400-e29b-41d4-a716-446655440001', 'San Francisco', 'CA', '94102', 'USA', 'OPERATIONAL', NOW(), NOW()),
('770e8400-e29b-41d4-a716-446655440002', 'Tech Solutions HQ', '456 Oak Ave', '660e8400-e29b-41d4-a716-446655440002', 'Oakland', 'CA', '94601', 'USA', 'OPERATIONAL', NOW(), NOW());

-- Insert demo technicians
INSERT INTO technicians (id, employee_id, first_name, last_name, email, phone_number, specialization, status, created_at, updated_at) VALUES
('880e8400-e29b-41d4-a716-446655440001', 'TECH001', 'John', 'Technician', 'john@keystone.com', '+1234567893', 'Electrical', 'ACTIVE', NOW(), NOW()),
('880e8400-e29b-41d4-a716-446655440002', 'TECH002', 'Jane', 'Worker', 'jane@keystone.com', '+1234567894', 'General', 'ACTIVE', NOW(), NOW());

-- Insert demo work orders (without technician references for simplicity)
INSERT INTO work_orders (id, work_order_number, customer_id, site_id, technician_id, title, description, priority, status, scheduled_date, created_at, updated_at) VALUES
('990e8400-e29b-41d4-a716-446655440001', 'WO-2026-001', '660e8400-e29b-41d4-a716-446655440001', '770e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440004', 'HVAC Maintenance', 'Regular maintenance of HVAC system', 'MEDIUM', 'IN_PROGRESS', NOW() + INTERVAL '1 day', NOW(), NOW()),
('990e8400-e29b-41d4-a716-446655440002', 'WO-2026-002', '660e8400-e29b-41d4-a716-446655440002', '770e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440005', 'Electrical Inspection', 'Annual electrical system inspection', 'HIGH', 'ASSIGNED', NOW() + INTERVAL '2 days', NOW(), NOW());

-- Insert demo complaints
INSERT INTO complaints (id, customer_id, service_type, description, priority, status, assigned_to, created_at, updated_at) VALUES
('aa0e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440006', 'Electrical', 'Power outage in office area', 'HIGH', 'IN_PROGRESS', '550e8400-e29b-41d4-a716-446655440004', NOW(), NOW()),
('aa0e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440006', 'Plumbing', 'Leaking pipe in restroom', 'MEDIUM', 'PENDING', NULL, NOW(), NOW());
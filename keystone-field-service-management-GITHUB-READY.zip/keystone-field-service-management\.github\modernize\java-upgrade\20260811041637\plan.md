# Upgrade Plan: keystone-field-service-management (20260811041637)

- **Generated**: 2026-08-11 04:16:37
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21.0.11: C:\Program Files\Microsoft\jdk-21.0.11.10-hotspot\bin (current project JDK, used by Step 2)
- JDK 25.0.2: C:\Users\ASUS\.jdks\jdk-25.0.2\bin (required by Step 3 and Step 5)

**Build Tools**
- Maven Wrapper: 3.9.9 via `backend\.mvn\wrapper\maven-wrapper.properties` (sufficient for Java 25)
- Maven 3.10.0-rc-1: C:\Users\ASUS\.maven\maven-3.10.0-rc-1\bin (available as a secondary build tool)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260811041637
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java runtime from 21 to 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible | Why Incompatible |
| --------------------- | ------- | -------------- | ---------------- |
| Java | 21 | 25 | User requested latest LTS runtime |
| Spring Boot | 3.5.0 | 3.5.0 | Compatible with Java 25; no Spring Boot upgrade required for JDK bump |
| Maven Wrapper | 3.9.9 | 3.9.0 | Maven 3.9.x is compatible with Java 25 and is already present |
| spring-boot-starter-parent | 3.5.0 | 3.5.0 | Managed plugin versions are adequate for this upgrade |

## Derived Upgrades

- Update `<java.version>` in `backend/pom.xml` from `21` to `25` because Spring Boot 3.5.x supports Java 25 and the user requested the latest LTS runtime.
- Keep Maven Wrapper at 3.9.9 because it is compatible with Java 25 and no wrapper upgrade is required at this time.
- Preserve existing Spring Boot 3.5.0 dependency management, as the runtime upgrade does not require a Spring Boot major version bump.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| backend/pom.xml | `<java.version>` | 21 | upgrade | 25 | Align runtime with latest LTS requested by user |

### Source Code Changes

No source code changes are expected for this upgrade. The runtime bump is isolated to Maven build configuration.

### Configuration Changes

No external configuration changes are required at this time.

### CI/CD Changes

No CI/CD files were detected for this workspace that require update.

### Risks & Warnings

- **Runtime compatibility risk**: Java 25 may surface JDK internal API or module changes not detected by source inspection. Mitigation: run full test suite with JDK 25 and update build plugins if compile/test failures reveal incompatibilities.
- **Managed plugin compatibility**: Spring Boot parent manages the compiler and test plugins. If Java 25 causes plugin issues, update the managed plugin versions only if necessary during execution.
- **Version control absent**: Repository is not a git repository, so changes will not be under branch control. Track modifications in `progress.md` and note that `HEAD Branch` / `HEAD Commit ID` are unavailable.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Confirm JDK 25 availability and Maven build tool readiness before changing the project.
  - **Changes to Make**: Validate `appmod-list-jdks` and `mvnw` availability. Record the selected JDK and wrapper path.
  - **Verification**: `java -version` for JDK 25 and `backend\mvnw -v` using the wrapper.

- Step 2: Setup Baseline
  - **Rationale**: Capture the current baseline compile and test behavior on Java 21 before the upgrade.
  - **Changes to Make**: None to project files; run baseline validation.
  - **Verification**: `backend\mvnw -q clean compile test-compile && backend\mvnw -q clean test` using JDK 21.

- Step 3: Upgrade Java runtime to 25
  - **Rationale**: Apply the minimal requested runtime upgrade in the Maven build configuration.
  - **Changes to Make**: Update `<java.version>` in `backend/pom.xml` to `25`.
  - **Verification**: `backend\mvnw -q clean test-compile` using JDK 25.

- Step 4: CVE Validation & Fix
  - **Rationale**: Scan direct dependencies for known vulnerabilities and fix any issues introduced or revealed by the upgrade.
  - **Changes to Make**: Use `mvn` dependency listing and `#appmod-validate-cves-for-java`; upgrade any vulnerable direct dependencies or BOM-managed versions as needed.
  - **Verification**: `backend\mvnw -q clean test-compile` after fixes, followed by a re-scan.

- Step 5: Final Validation
  - **Rationale**: Ensure the upgrade meets all success criteria with full test coverage on Java 25.
  - **Changes to Make**: Address any compile or test failures discovered after the runtime bump.
  - **Verification**: `backend\mvnw -q clean test` using JDK 25.

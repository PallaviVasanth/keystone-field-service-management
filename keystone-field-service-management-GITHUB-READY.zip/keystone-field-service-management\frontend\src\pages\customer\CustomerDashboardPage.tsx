import { useState, useEffect } from 'react';
import { Box, Button, Card, CardContent, Grid, Stack, Typography, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem, Alert, CircularProgress } from '@mui/material';
import { FiPlus, FiClock, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';
import { PageHeader } from '../../components/common/PageHeader';
import { StatCard } from '../../components/common/StatCard';
import { DataTable } from '../../components/common/DataTable';
import { StatusBadge } from '../../components/common/StatusBadge';
import { useAuth } from '../../context/AuthContext';
import { complaintService } from '../../services/apiService';
import type { Complaint } from '../../types';

export const CustomerDashboardPage = () => {
  const { user } = useAuth();
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [openDialog, setOpenDialog] = useState(false);
  const [newComplaint, setNewComplaint] = useState({
    serviceType: '',
    description: '',
    priority: 'MEDIUM' as 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadComplaints();
  }, []);

  const loadComplaints = async () => {
    try {
      setIsLoading(true);
      const data = await complaintService.getAll();
      setComplaints(data);
    } catch (err) {
      console.error('Failed to load complaints:', err);
      setError('Failed to load complaints');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateComplaint = async () => {
    try {
      setError('');
      await complaintService.create({
        customerId: user?.id || '',
        serviceType: newComplaint.serviceType,
        description: newComplaint.description,
        priority: newComplaint.priority,
        status: 'PENDING',
      });
      setSuccess('Complaint created successfully');
      setOpenDialog(false);
      setNewComplaint({ serviceType: '', description: '', priority: 'MEDIUM' });
      loadComplaints();
      setTimeout(() => setSuccess(''), 3000);
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to create complaint');
    }
  };



  const stats = {
    total: complaints.length,
    pending: complaints.filter(c => c.status === 'PENDING').length,
    inProgress: complaints.filter(c => c.status === 'IN_PROGRESS').length,
    completed: complaints.filter(c => c.status === 'RESOLVED').length,
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {success && <Alert severity="success" sx={{ mb: 2 }}>{success}</Alert>}
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      
      <Card sx={{ mb: 3, background: 'linear-gradient(135deg, #10B981 0%, #059669 45%, #047857 100%)', color: 'white', border: 'none' }}>
        <CardContent sx={{ p: { xs: 3, md: 4 } }}>
          <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'flex-start', md: 'center' }} spacing={2}>
            <Box>
              <Typography variant="h5" fontWeight={800}>Customer Portal</Typography>
              <Typography sx={{ mt: 1, opacity: 0.92 }}>Submit service requests and track their progress</Typography>
            </Box>
            <Button 
              variant="contained" 
              sx={{ bgcolor: 'white', color: 'success.main', '&:hover': { bgcolor: 'grey.100' } }} 
              startIcon={<FiPlus />}
              onClick={() => setOpenDialog(true)}
            >
              New Complaint
            </Button>
          </Stack>
        </CardContent>
      </Card>

      <PageHeader title="My Service Requests" subtitle="Track and manage your service complaints" />

      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={3}>
          <StatCard title="Total Requests" value={stats.total} subtitle="All time" icon={<FiClock size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="Pending" value={stats.pending} subtitle="Awaiting assignment" icon={<FiAlertCircle size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="In Progress" value={stats.inProgress} subtitle="Being addressed" icon={<FiClock size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="Completed" value={stats.completed} subtitle="Ready for confirmation" icon={<FiCheckCircle size={20} />} />
        </Grid>
      </Grid>

      <Card>
        <CardContent>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>My Complaints</Typography>
          <DataTable 
            rows={complaints} 
            columns={[
              { key: 'id', label: 'ID' },
              { key: 'serviceType', label: 'Service Type' },
              { key: 'description', label: 'Description' },
              { key: 'priority', label: 'Priority' },
              { key: 'status', label: 'Status', render: (row) => <StatusBadge label={row.status} color={row.status === 'RESOLVED' ? 'success' : row.status === 'PENDING' ? 'warning' : 'primary'} /> },
              { key: 'createdAt', label: 'Created' },
            ]} 
          />
        </CardContent>
      </Card>

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create New Service Complaint</DialogTitle>
        <DialogContent>
          <Stack spacing={2} sx={{ mt: 2 }}>
            <TextField
              label="Service Type"
              select
              fullWidth
              value={newComplaint.serviceType}
              onChange={(e) => setNewComplaint({ ...newComplaint, serviceType: e.target.value })}
            >
              <MenuItem value="Electrical">Electrical</MenuItem>
              <MenuItem value="Plumbing">Plumbing</MenuItem>
              <MenuItem value="HVAC">HVAC</MenuItem>
              <MenuItem value="General">General Maintenance</MenuItem>
              <MenuItem value="Other">Other</MenuItem>
            </TextField>
            <TextField
              label="Priority"
              select
              fullWidth
              value={newComplaint.priority}
              onChange={(e) => setNewComplaint({ ...newComplaint, priority: e.target.value as any })}
            >
              <MenuItem value="LOW">Low</MenuItem>
              <MenuItem value="MEDIUM">Medium</MenuItem>
              <MenuItem value="HIGH">High</MenuItem>
              <MenuItem value="CRITICAL">Critical</MenuItem>
            </TextField>
            <TextField
              label="Description"
              multiline
              rows={4}
              fullWidth
              value={newComplaint.description}
              onChange={(e) => setNewComplaint({ ...newComplaint, description: e.target.value })}
              placeholder="Describe your issue in detail..."
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
          <Button onClick={handleCreateComplaint} variant="contained">Submit Complaint</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};
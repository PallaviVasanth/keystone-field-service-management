import { useState, useEffect } from 'react';
import { Box, Card, CardContent, Grid, Stack, Typography, Alert, CircularProgress } from '@mui/material';
import { FiClock, FiCheckCircle, FiPlayCircle, FiTool } from 'react-icons/fi';
import { PageHeader } from '../../components/common/PageHeader';
import { StatCard } from '../../components/common/StatCard';
import { DataTable } from '../../components/common/DataTable';
import { StatusBadge } from '../../components/common/StatusBadge';
import { useAuth } from '../../context/AuthContext';
import { workOrderService } from '../../services/apiService';
import type { WorkOrder } from '../../types';

export const TechnicianDashboardPage = () => {
  const { user } = useAuth();
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadWorkOrders();
  }, []);

  const loadWorkOrders = async () => {
    try {
      setIsLoading(true);
      const data = await workOrderService.getAll();
      // Filter for assigned work orders for this technician
      const myWorkOrders = data.filter(wo => wo.technicianId === user?.id);
      setWorkOrders(myWorkOrders);
    } catch (err) {
      console.error('Failed to load work orders:', err);
      setError('Failed to load work orders');
    } finally {
      setIsLoading(false);
    }
  };

  const stats = {
    total: workOrders.length,
    assigned: workOrders.filter(wo => wo.status === 'ASSIGNED').length,
    inProgress: workOrders.filter(wo => wo.status === 'IN_PROGRESS').length,
    completed: workOrders.filter(wo => wo.status === 'COMPLETED').length,
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      
      <Card sx={{ mb: 3, background: 'linear-gradient(135deg, #F59E0B 0%, #D97706 45%, #B45309 100%)', color: 'white', border: 'none' }}>
        <CardContent sx={{ p: { xs: 3, md: 4 } }}>
          <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'flex-start', md: 'center' }} spacing={2}>
            <Box>
              <Typography variant="h5" fontWeight={800}>Technician Portal</Typography>
              <Typography sx={{ mt: 1, opacity: 0.92 }}>Manage your assigned work orders and track progress</Typography>
            </Box>
          </Stack>
        </CardContent>
      </Card>

      <PageHeader title="My Work Orders" subtitle="View and update your assigned tasks" />

      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid item xs={12} md={3}>
          <StatCard title="Total Assigned" value={stats.total} subtitle="All work orders" icon={<FiTool size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="Assigned" value={stats.assigned} subtitle="Ready to start" icon={<FiClock size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="In Progress" value={stats.inProgress} subtitle="Currently working" icon={<FiPlayCircle size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="Completed" value={stats.completed} subtitle="Finished tasks" icon={<FiCheckCircle size={20} />} />
        </Grid>
      </Grid>

      <Card>
        <CardContent>
          <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Assigned Work Orders</Typography>
          <DataTable 
            rows={workOrders} 
            columns={[
              { key: 'workOrderNumber', label: 'Work Order #' },
              { key: 'title', label: 'Title' },
              { key: 'customerName', label: 'Customer' },
              { key: 'siteName', label: 'Site' },
              { key: 'priority', label: 'Priority' },
              { key: 'status', label: 'Status', render: (row) => <StatusBadge label={row.status} color={row.status === 'COMPLETED' ? 'success' : row.status === 'ASSIGNED' ? 'warning' : 'primary'} /> },
              { key: 'scheduledDate', label: 'Scheduled' },
            ]} 
          />
        </CardContent>
      </Card>
    </Box>
  );
};
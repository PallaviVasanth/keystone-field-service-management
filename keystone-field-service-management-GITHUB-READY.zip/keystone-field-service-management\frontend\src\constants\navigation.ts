import { FiGrid, FiUsers, FiMapPin, FiClipboard, FiBarChart2, FiSettings, FiUser, FiShield } from 'react-icons/fi';
import type { UserRole } from '../types';

export interface NavItem {
  label: string;
  path: string;
  icon: typeof FiGrid;
  roles: UserRole[];
}

export const navItems: NavItem[] = [
  { label: 'Dashboard', path: '/dashboard', icon: FiGrid, roles: ['ADMIN', 'DISPATCHER', 'MANAGER', 'TECHNICIAN', 'WORKER', 'CUSTOMER'] },
  { label: 'Customers', path: '/customers', icon: FiUsers, roles: ['ADMIN', 'MANAGER', 'DISPATCHER'] },
  { label: 'Sites', path: '/sites', icon: FiMapPin, roles: ['ADMIN', 'MANAGER', 'DISPATCHER'] },
  { label: 'Work Orders', path: '/work-orders', icon: FiClipboard, roles: ['ADMIN', 'DISPATCHER', 'MANAGER', 'TECHNICIAN', 'WORKER'] },
  { label: 'Dispatcher', path: '/dispatcher', icon: FiShield, roles: ['ADMIN', 'DISPATCHER', 'MANAGER'] },
  { label: 'Analytics', path: '/analytics', icon: FiBarChart2, roles: ['ADMIN', 'MANAGER'] },
  { label: 'Profile', path: '/profile', icon: FiUser, roles: ['ADMIN', 'DISPATCHER', 'MANAGER', 'TECHNICIAN', 'WORKER', 'CUSTOMER'] },
  { label: 'Settings', path: '/settings', icon: FiSettings, roles: ['ADMIN', 'DISPATCHER', 'MANAGER', 'TECHNICIAN', 'WORKER', 'CUSTOMER'] },
];

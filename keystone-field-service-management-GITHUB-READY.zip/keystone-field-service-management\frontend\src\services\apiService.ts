import api from './api';
import { dashboardStats, workOrders } from './mockData';
import type { 
  LoginRequest, 
  LoginResponse, 
  RegisterRequest, 
  User, 
  WorkOrder, 
  Complaint,
  DashboardStats 
} from '../types';

// Auth Service
export const authService = {
  login: async (credentials: LoginRequest): Promise<LoginResponse> => {
    const response = await api.post<LoginResponse>('/auth/login', credentials);
    return response.data;
  },

  register: async (userData: RegisterRequest): Promise<User> => {
    const response = await api.post<User>('/auth/register', userData);
    return response.data;
  },

  logout: () => {
    localStorage.removeItem('keystone-token');
    localStorage.removeItem('keystone-user');
  },
};

// Work Order Service
export const workOrderService = {
  getAll: async (): Promise<WorkOrder[]> => {
    try {
      const response = await api.get<WorkOrder[]>('/workorders');
      return response.data;
    } catch (error) {
      console.log('Using mock data for work orders');
      return workOrders;
    }
  },

  getById: async (id: string): Promise<WorkOrder> => {
    try {
      const response = await api.get<WorkOrder>(`/workorders/${id}`);
      return response.data;
    } catch (error) {
      return workOrders.find(wo => wo.id === id) || workOrders[0];
    }
  },

  create: async (data: Partial<WorkOrder>): Promise<WorkOrder> => {
    try {
      const response = await api.post<WorkOrder>('/workorders', data);
      return response.data;
    } catch (error) {
      // Return mock data for demo
      return { ...workOrders[0], ...data, id: `wo${Date.now()}` } as WorkOrder;
    }
  },

  update: async (id: string, data: Partial<WorkOrder>): Promise<WorkOrder> => {
    try {
      const response = await api.put<WorkOrder>(`/workorders/${id}`, data);
      return response.data;
    } catch (error) {
      const existing = workOrders.find(wo => wo.id === id) || workOrders[0];
      return { ...existing, ...data } as WorkOrder;
    }
  },

  delete: async (id: string): Promise<void> => {
    try {
      await api.delete(`/workorders/${id}`);
    } catch (error) {
      console.log('Mock delete operation');
    }
  },

  assignTechnician: async (id: string, technicianId: string): Promise<WorkOrder> => {
    try {
      const response = await api.put<WorkOrder>(`/workorders/${id}/assign`, { technicianId });
      return response.data;
    } catch (error) {
      const existing = workOrders.find(wo => wo.id === id) || workOrders[0];
      return { ...existing, technicianId, status: 'ASSIGNED' } as WorkOrder;
    }
  },

  updateStatus: async (id: string, status: string): Promise<WorkOrder> => {
    try {
      const response = await api.put<WorkOrder>(`/workorders/${id}/status`, { status });
      return response.data;
    } catch (error) {
      const existing = workOrders.find(wo => wo.id === id) || workOrders[0];
      return { ...existing, status } as WorkOrder;
    }
  },
};

// Complaint Service
export const complaintService = {
  getAll: async (): Promise<Complaint[]> => {
    try {
      const response = await api.get<Complaint[]>('/complaints');
      return response.data;
    } catch (error) {
      // Return mock complaints
      return [
        {
          id: 'c1',
          customerId: 'demo-customer',
          serviceType: 'Electrical',
          description: 'Power outage in office area',
          priority: 'HIGH',
          status: 'PENDING',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: 'c2',
          customerId: 'demo-customer',
          serviceType: 'Plumbing',
          description: 'Leaking pipe in restroom',
          priority: 'MEDIUM',
          status: 'IN_PROGRESS',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ];
    }
  },

  getById: async (id: string): Promise<Complaint> => {
    try {
      const response = await api.get<Complaint>(`/complaints/${id}`);
      return response.data;
    } catch (error) {
      const complaints = await complaintService.getAll();
      return complaints.find(c => c.id === id) || complaints[0];
    }
  },

  create: async (data: Partial<Complaint>): Promise<Complaint> => {
    try {
      const response = await api.post<Complaint>('/complaints', data);
      return response.data;
    } catch (error) {
      return {
        id: `c${Date.now()}`,
        customerId: data.customerId || 'demo-customer',
        serviceType: data.serviceType || 'General',
        description: data.description || '',
        priority: data.priority || 'MEDIUM',
        status: 'PENDING',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      } as Complaint;
    }
  },

  update: async (id: string, data: Partial<Complaint>): Promise<Complaint> => {
    try {
      const response = await api.put<Complaint>(`/complaints/${id}`, data);
      return response.data;
    } catch (error) {
      const complaints = await complaintService.getAll();
      const existing = complaints.find(c => c.id === id) || complaints[0];
      return { ...existing, ...data } as Complaint;
    }
  },

  getByCustomer: async (customerId: string): Promise<Complaint[]> => {
    try {
      const response = await api.get<Complaint[]>(`/complaints/customer/${customerId}`);
      return response.data;
    } catch (error) {
      return (await complaintService.getAll()).filter(c => c.customerId === customerId);
    }
  },

  confirmCompletion: async (id: string): Promise<Complaint> => {
    try {
      const response = await api.put<Complaint>(`/complaints/${id}/confirm`);
      return response.data;
    } catch (error) {
      const complaints = await complaintService.getAll();
      const existing = complaints.find(c => c.id === id) || complaints[0];
      return { ...existing, status: 'RESOLVED' } as Complaint;
    }
  },
};

// Dashboard Service
export const dashboardService = {
  getStats: async (): Promise<DashboardStats> => {
    try {
      const response = await api.get<DashboardStats>('/dashboard/stats');
      return response.data;
    } catch (error) {
      console.log('Using mock dashboard stats');
      return dashboardStats;
    }
  },
};

// User Service
export const userService = {
  getCurrentUser: async (): Promise<User> => {
    try {
      const response = await api.get<User>('/users/me');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getAll: async (): Promise<User[]> => {
    try {
      const response = await api.get<User[]>('/users');
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getById: async (id: string): Promise<User> => {
    try {
      const response = await api.get<User>(`/users/${id}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },

  getByRole: async (role: string): Promise<User[]> => {
    try {
      const response = await api.get<User[]>(`/users/role/${role}`);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
};
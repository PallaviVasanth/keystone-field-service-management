export type UserRole = 'ADMIN' | 'DISPATCHER' | 'MANAGER' | 'TECHNICIAN' | 'CUSTOMER' | 'WORKER';

export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
  phoneNumber?: string;
  active: boolean;
  createdAt: string;
  updatedAt: string;
  avatar?: string;
}

export interface Customer {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  address: string;
  status: 'Active' | 'Pending' | 'Inactive';
}

export interface Site {
  id: string;
  name: string;
  address: string;
  customerId: string;
  status: 'Operational' | 'Maintenance' | 'Offline';
}

export interface WorkOrder {
  id: string;
  workOrderNumber: string;
  customerId: string;
  customerName?: string;
  siteId: string;
  siteName?: string;
  technicianId?: string;
  technicianName?: string;
  title: string;
  description: string;
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  status: 'PENDING' | 'ASSIGNED' | 'IN_PROGRESS' | 'ON_HOLD' | 'COMPLETED' | 'CUSTOMER_CONFIRMED' | 'CLOSED';
  scheduledDate?: string;
  completedDate?: string;
  createdAt: string;
  updatedAt: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
}

export interface DashboardStats {
  totalWorkOrders: number;
  completedToday: number;
  activeTechnicians: number;
  pendingComplaints: number;
  revenue: number;
}

export interface Complaint {
  id: string;
  customerId: string;
  customerName?: string;
  serviceType: string;
  description: string;
  status: 'PENDING' | 'ASSIGNED' | 'IN_PROGRESS' | 'RESOLVED' | 'CUSTOMER_CONFIRMED' | 'CLOSED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  createdAt: string;
  updatedAt: string;
  assignedTo?: string;
  assignedToName?: string;
  completedAt?: string;
  customerConfirmedAt?: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  tokenType: string;
  userId: string;
  firstName: string;
  lastName: string;
  email: string;
  role: UserRole;
}

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phoneNumber?: string;
  role: UserRole;
}

import type { ReactNode } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { MainLayout } from './layouts/MainLayout';
import { LoginPage } from './pages/auth/LoginPage';
import { RegisterPage } from './pages/auth/RegisterPage';
import { DashboardPage } from './pages/dashboard/DashboardPage';
import { CustomersPage } from './pages/customers/CustomersPage';
import { SitesPage } from './pages/sites/SitesPage';
import { WorkOrdersPage } from './pages/work-orders/WorkOrdersPage';
import { DispatcherPage } from './pages/dispatcher/DispatcherPage';
import { AnalyticsPage } from './pages/analytics/AnalyticsPage';
import { ProfilePage } from './pages/profile/ProfilePage';
import { SettingsPage } from './pages/settings/SettingsPage';
import { UnauthorizedPage } from './pages/auth/UnauthorizedPage';
import { NotFoundPage } from './pages/auth/NotFoundPage';
import { CustomerDashboardPage } from './pages/customer/CustomerDashboardPage';
import { TechnicianDashboardPage } from './pages/technician/TechnicianDashboardPage';
import { WorkerDashboardPage } from './pages/worker/WorkerDashboardPage';
import { AuthProvider, useAuth } from './context/AuthContext';

const ProtectedRoute = ({ children }: { children: ReactNode }) => {
  const { user, isLoading } = useAuth();
  if (isLoading) {
    return <div>Loading...</div>;
  }
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
};

const RoleRoute = ({ children, allowedRoles }: { children: ReactNode; allowedRoles: string[] }) => {
  const { role } = useAuth();
  if (!allowedRoles.includes(role)) {
    return <Navigate to="/unauthorized" replace />;
  }
  return <>{children}</>;
};

const AppRoutes = () => {
  const { role } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/unauthorized" element={<UnauthorizedPage />} />
      <Route element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        
        {/* Role-based dashboard routing */}
        <Route path="/dashboard" element={
          role === 'CUSTOMER' ? <CustomerDashboardPage /> :
          role === 'TECHNICIAN' ? <TechnicianDashboardPage /> :
          role === 'WORKER' ? <WorkerDashboardPage /> :
          <DashboardPage />
        } />
        
        {/* Manager/Admin routes */}
        <Route path="/customers" element={<RoleRoute allowedRoles={['ADMIN', 'MANAGER', 'DISPATCHER']}><CustomersPage /></RoleRoute>} />
        <Route path="/sites" element={<RoleRoute allowedRoles={['ADMIN', 'MANAGER', 'DISPATCHER']}><SitesPage /></RoleRoute>} />
        <Route path="/work-orders" element={<WorkOrdersPage />} />
        <Route path="/dispatcher" element={<RoleRoute allowedRoles={['ADMIN', 'MANAGER', 'DISPATCHER']}><DispatcherPage /></RoleRoute>} />
        <Route path="/analytics" element={<RoleRoute allowedRoles={['ADMIN', 'MANAGER']}><AnalyticsPage /></RoleRoute>} />
        
        {/* Common routes */}
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  );
};

export default App;

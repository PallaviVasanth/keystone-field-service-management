package com.keystone.complaint.controller;

import com.keystone.complaint.dto.ComplaintResponse;
import com.keystone.complaint.dto.CreateComplaintRequest;
import com.keystone.complaint.dto.UpdateComplaintRequest;
import com.keystone.complaint.service.ComplaintService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/complaints")
@RequiredArgsConstructor
public class ComplaintController {

    private final ComplaintService complaintService;

    @PostMapping
    public ResponseEntity<ComplaintResponse> createComplaint(
            @Valid @RequestBody CreateComplaintRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(complaintService.createComplaint(request));
    }

    @GetMapping
    public ResponseEntity<List<ComplaintResponse>> getAllComplaints() {
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ComplaintResponse> getComplaintById(
            @PathVariable UUID id) {
        return ResponseEntity.ok(complaintService.getComplaintById(id));
    }

    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<ComplaintResponse>> getComplaintsByCustomer(
            @PathVariable UUID customerId) {
        return ResponseEntity.ok(complaintService.getComplaintsByCustomer(customerId));
    }

    @GetMapping("/assigned/{assignedTo}")
    public ResponseEntity<List<ComplaintResponse>> getComplaintsByAssignedTo(
            @PathVariable UUID assignedTo) {
        return ResponseEntity.ok(complaintService.getComplaintsByAssignedTo(assignedTo));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ComplaintResponse> updateComplaint(
            @PathVariable UUID id,
            @Valid @RequestBody UpdateComplaintRequest request) {
        return ResponseEntity.ok(complaintService.updateComplaint(id, request));
    }

    @PutMapping("/{id}/confirm")
    public ResponseEntity<ComplaintResponse> confirmCompletion(
            @PathVariable UUID id) {
        return ResponseEntity.ok(complaintService.confirmCompletion(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteComplaint(
            @PathVariable UUID id) {
        complaintService.deleteComplaint(id);
        return ResponseEntity.noContent().build();
    }
}
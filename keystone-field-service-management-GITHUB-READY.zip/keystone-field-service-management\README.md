# Keystone - Field Service Management Application

A comprehensive, professional full-stack field service management system built with modern technologies. Keystone enables organizations to manage service requests, dispatch technicians, track work orders, and provide customers with real-time visibility into service progress.

## 🌟 Features

### Role-Based Access Control
- **Customer**: Submit service complaints, track progress, confirm completed work
- **Manager**: Overview of all operations, assign tasks, monitor team performance
- **Technician**: View assigned work orders, update status, track progress
- **Worker**: View assigned tasks, update progress, mark completion
- **Dispatcher**: Coordinate service assignments, manage schedules
- **Admin**: Full system access and configuration

### Core Functionality
- **Service Request Management**: Customers can submit detailed service complaints with priority levels
- **Work Order Assignment**: Managers can assign technicians to specific tasks with deadlines
- **Real-time Status Tracking**: Track work order status from submission to completion
- **Customer Confirmation**: Customers verify and confirm completed work
- **Dashboard Analytics**: Role-specific dashboards with relevant metrics and KPIs
- **Professional UI**: Modern, responsive interface built with Material-UI
- **Secure Authentication**: JWT-based authentication with role-based authorization

## 🛠 Technology Stack

### Frontend
- **React 19** - Modern React with latest features
- **TypeScript** - Type-safe development
- **Material-UI (MUI)** - Professional UI components
- **React Router** - Client-side routing
- **Axios** - HTTP client for API calls
- **React Hook Form** - Form management
- **Vite** - Fast build tool and dev server

### Backend
- **Spring Boot 3.5** - Enterprise Java framework
- **Java 21** - Latest Java LTS version
- **Spring Security** - Authentication and authorization
- **Spring Data JPA** - Database abstraction
- **JWT (JJWT)** - Token-based authentication
- **H2 Database** - In-memory database for development
- **PostgreSQL** - Production database support
- **Flyway** - Database migration management
- **Maven** - Build and dependency management
- **Swagger/OpenAPI** - API documentation

## 📁 Project Structure

```
keystone-field-service-management/
├── frontend/                 # React frontend application
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   │   ├── common/      # Shared components (DataTable, StatCard, etc.)
│   │   │   └── layout/      # Layout components (Sidebar, Topbar)
│   │   ├── context/         # React context providers (Auth, Theme)
│   │   ├── pages/           # Page components
│   │   │   ├── auth/        # Authentication pages
│   │   │   ├── customer/    # Customer-specific pages
│   │   │   ├── technician/  # Technician-specific pages
│   │   │   ├── worker/      # Worker-specific pages
│   │   │   └── dashboard/   # Dashboard pages
│   │   ├── services/        # API service layer
│   │   ├── styles/          # Global styles
│   │   ├── theme/           # Material-UI theme configuration
│   │   ├── types/           # TypeScript type definitions
│   │   ├── constants/       # Application constants
│   │   ├── layouts/         # Page layouts
│   │   ├── App.tsx          # Main application component
│   │   └── main.tsx         # Application entry point
│   ├── public/              # Static assets
│   ├── .env                 # Environment variables
│   ├── .env.example         # Environment variables template
│   ├── package.json         # Frontend dependencies
│   ├── tsconfig.json        # TypeScript configuration
│   └── vite.config.ts       # Vite configuration
│
├── backend/                 # Spring Boot backend application
│   ├── src/
│   │   └── main/
│   │       ├── java/com/keystone/
│   │       │   ├── auth/           # Authentication module
│   │       │   │   ├── controller/
│   │       │   │   ├── dto/
│   │       │   │   └── service/
│   │       │   ├── complaint/      # Complaint management module
│   │       │   │   ├── controller/
│   │       │   │   ├── dto/
│   │       │   │   ├── entity/
│   │       │   │   ├── repository/
│   │       │   │   └── service/
│   │       │   ├── config/         # Configuration classes
│   │       │   ├── customer/       # Customer management module
│   │       │   ├── dashboard/      # Dashboard statistics module
│   │       │   ├── security/       # Security configuration
│   │       │   ├── site/           # Site/location management
│   │       │   ├── technician/     # Technician management
│   │       │   ├── user/           # User management
│   │       │   ├── workorder/      # Work order management
│   │       │   └── KeystoneBackendApplication.java
│   │       └── resources/
│   │           ├── application.yml          # Main configuration
│   │           ├── application-dev.yml      # Development configuration
│   │           ├── application-prod.yml     # Production configuration
│   │           └── db/migration/             # Database migrations
│   ├── .env.example         # Environment variables template
│   ├── pom.xml              # Maven configuration
│   └── README.md            # Backend documentation
│
└── README.md                # This file
```

## 🚀 Getting Started

### Prerequisites

- **Node.js** (v18 or higher) - [Download](https://nodejs.org/)
- **Java 21** - [Download](https://www.oracle.com/java/technologies/downloads/)
- **Maven** (3.8 or higher) - [Download](https://maven.apache.org/download.cgi)
- **Git** - [Download](https://git-scm.com/downloads)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd keystone-field-service-management
   ```

2. **Backend Setup**
   ```bash
   cd backend
   cp .env.example .env
   # Edit .env with your configuration if needed
   mvn clean install
   ```

3. **Frontend Setup**
   ```bash
   cd frontend
   cp .env.example .env
   npm install
   ```

## 🔧 Configuration

### Backend Environment Variables

Create a `.env` file in the `backend` directory:

```env
# Database Configuration
SPRING_PROFILES_ACTIVE=dev
SERVER_PORT=8080

# JWT Configuration
JWT_SECRET=ThisIsMyVeryStrongJwtSecretKeyForKeystoneProject2026@12345
JWT_EXPIRATION_MS=86400000

# CORS Configuration
CORS_ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000

# Database (for production)
# SPRING_DATASOURCE_URL=jdbc:postgresql://localhost:5432/keystone_prod
# SPRING_DATASOURCE_USERNAME=postgres
# SPRING_DATASOURCE_PASSWORD=your_password
```

### Frontend Environment Variables

Create a `.env` file in the `frontend` directory:

```env
VITE_API_BASE_URL=http://localhost:8080/api
```

## 🏃 Running the Application

### Start the Backend

```bash
cd backend
mvn spring-boot:run
```

The backend will start on `http://localhost:8080`

- API Base URL: `http://localhost:8080/api`
- Swagger UI: `http://localhost:8080/api/swagger-ui.html`
- H2 Console: `http://localhost:8080/api/h2-console` (dev mode only)

### Start the Frontend

```bash
cd frontend
npm run dev
```

The frontend will start on `http://localhost:5173`

## 👥 User Roles & Authentication

### Demo Accounts

The application comes with pre-configured demo accounts (password: `password123`):

| Role | Email | Purpose |
|------|-------|---------|
| Admin | admin@keystone.com | Full system access |
| Manager | manager@keystone.com | Operations oversight |
| Dispatcher | dispatcher@keystone.com | Task assignment |
| Technician | technician@keystone.com | Field work execution |
| Worker | worker@keystone.com | Task completion |
| Customer | customer@keystone.com | Service requests |

### Role Permissions

**Admin**
- Full access to all features
- User management
- System configuration

**Manager**
- View all work orders and complaints
- Assign technicians to tasks
- Monitor team performance
- Access analytics and reports

**Dispatcher**
- View and assign work orders
- Manage technician schedules
- Coordinate service delivery

**Technician**
- View assigned work orders
- Update work order status
- Add progress notes
- Mark work as completed

**Worker**
- View assigned tasks
- Update task progress
- Mark tasks as completed

**Customer**
- Submit service complaints
- Track complaint status
- View service history
- Confirm completed work

## 🔄 Main Workflows

### 1. Customer Complaint Workflow
1. Customer logs in and navigates to Customer Portal
2. Customer clicks "New Complaint" and fills in:
   - Service type (Electrical, Plumbing, HVAC, etc.)
   - Priority level
   - Detailed description
3. Complaint is submitted with status "PENDING"
4. Customer can track status in their dashboard

### 2. Manager Assignment Workflow
1. Manager views pending complaints in dashboard
2. Manager reviews complaint details
3. Manager assigns technician/worker to the complaint
4. System creates work order and updates status to "ASSIGNED"
5. Manager sets deadline and priority

### 3. Technician/Worker Execution Workflow
1. Technician/Worker logs in and views assigned tasks
2. Clicks "Update Status" to begin work
3. Updates status to "IN_PROGRESS"
4. Adds progress notes as work continues
5. Marks work as "COMPLETED" when finished

### 4. Customer Confirmation Workflow
1. Customer receives notification of completed work
2. Customer reviews work details
3. Customer clicks "Confirm Work" if satisfied
4. System updates status to "CUSTOMER_CONFIRMED"
5. Complaint is marked as resolved

## 🧪 Testing

### Backend Testing

```bash
cd backend
mvn test
```

### Frontend Testing

```bash
cd frontend
npm test
```

### Manual Testing Checklist

- [ ] All roles can log in successfully
- [ ] Customers can create complaints
- [ ] Managers can view and assign complaints
- [ ] Technicians can view and update assigned work
- [ ] Workers can view and update assigned tasks
- [ ] Customers can confirm completed work
- [ ] Dashboard statistics are accurate
- [ ] API endpoints respond correctly
- [ ] Authentication tokens work properly
- [ ] CORS is configured correctly

## 📊 Database Schema

### Key Tables

- **users**: User accounts with roles and authentication
- **customers**: Customer organization information
- **sites**: Customer locations/service sites
- **technicians**: Technician profiles and specializations
- **work_orders**: Service work orders and assignments
- **complaints**: Customer service complaints and requests
- **assets**: Equipment and asset tracking

### Database Migrations

Database migrations are managed with Flyway and located in:
`backend/src/main/resources/db/migration/`

## 🔒 Security Features

- **JWT Authentication**: Stateless token-based authentication
- **Password Hashing**: BCrypt encryption for password storage
- **CORS Configuration**: Controlled cross-origin access
- **Role-Based Access**: Server-side authorization checks
- **Secure Headers**: Security best practices in HTTP headers
- **SQL Injection Prevention**: JPA parameterized queries

## 🌐 API Documentation

Once the backend is running, access the interactive API documentation:

**Swagger UI**: `http://localhost:8080/api/swagger-ui.html`

This provides:
- Interactive API testing
- Request/response schemas
- Authentication examples
- Endpoint descriptions

## 🐛 Troubleshooting

### Common Issues

**Backend won't start**
- Check Java version (requires Java 21)
- Verify port 8080 is not in use
- Check database connection in application-dev.yml

**Frontend can't connect to backend**
- Verify backend is running on port 8080
- Check CORS configuration in SecurityConfig.java
- Ensure VITE_API_BASE_URL is correct in .env

**Login fails**
- Verify demo user credentials
- Check JWT secret configuration
- Review backend logs for authentication errors

**Database issues**
- For H2: Check h2-console is accessible
- For PostgreSQL: Verify connection details
- Run Flyway migrations manually if needed

## 📝 Development Notes

### Adding New Features

1. **Backend**: Create new module under `com.keystone.*`
2. **Frontend**: Add pages under `src/pages/`
3. **API**: Add service methods in `src/services/apiService.ts`
4. **Types**: Update TypeScript types in `src/types/index.ts`

### Code Style

- **Backend**: Follow Spring Boot conventions
- **Frontend**: Use ESLint and Prettier configurations
- **Commit**: Use descriptive commit messages

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is proprietary software. All rights reserved.

## 📞 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Review API documentation in Swagger UI

## 🎯 Future Enhancements

- [ ] Mobile application (React Native)
- [ ] Real-time notifications (WebSocket)
- [ ] Advanced reporting and analytics
- [ ] Integration with external systems
- [ ] Mobile-first responsive design improvements
- [ ] File upload for complaint attachments
- [ ] Technician GPS tracking
- [ ] Automated scheduling optimization
- [ ] Customer feedback and ratings
- [ ] Invoice and payment processing

---

**Built with ❤️ using modern web technologies**
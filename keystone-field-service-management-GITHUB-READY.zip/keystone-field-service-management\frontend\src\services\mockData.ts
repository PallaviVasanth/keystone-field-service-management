import type { Customer, DashboardStats, NotificationItem, Site, WorkOrder } from '../types';

export const dashboardStats: DashboardStats = {
  totalWorkOrders: 184,
  completedToday: 27,
  activeTechnicians: 14,
  pendingComplaints: 5,
  revenue: 128400,
};

export const customers: Customer[] = [
  { id: 'c1', name: 'Margaret Ross', company: 'Northwind Labs', email: 'mross@northwind.com', phone: '+1 415 555 0139', address: '150 Market St, San Francisco', status: 'Active' },
  { id: 'c2', name: 'Hector Flores', company: 'Apex Utilities', email: 'hflores@apex.com', phone: '+1 415 555 0142', address: '770 Harbor Ave, Oakland', status: 'Pending' },
  { id: 'c3', name: 'Oluwaseun Patel', company: 'BluePeak Health', email: 'opatel@bluepeak.com', phone: '+1 415 555 0148', address: '24 Cedar St, San Jose', status: 'Active' },
];

export const sites: Site[] = [
  { id: 's1', name: 'Northwind Data Center', address: '150 Market St, San Francisco', customerId: 'c1', status: 'Operational' },
  { id: 's2', name: 'Apex Substation', address: '770 Harbor Ave, Oakland', customerId: 'c2', status: 'Maintenance' },
  { id: 's3', name: 'BluePeak Clinic', address: '24 Cedar St, San Jose', customerId: 'c3', status: 'Operational' },
];

export const workOrders: WorkOrder[] = [
  { id: 'wo1', workOrderNumber: 'WO-001', title: 'HVAC optimization', customerId: 'c1', siteId: 's1', technicianId: 't1', status: 'PENDING', priority: 'HIGH', createdAt: '2026-07-24', scheduledDate: '2026-07-25', updatedAt: '2026-07-24', description: 'Inspect and optimize cooling performance before peak load.' },
  { id: 'wo2', workOrderNumber: 'WO-002', title: 'Generator service', customerId: 'c2', siteId: 's2', technicianId: 't2', status: 'ASSIGNED', priority: 'CRITICAL', createdAt: '2026-07-23', scheduledDate: '2026-07-24', updatedAt: '2026-07-23', description: 'Perform preventive maintenance on backup generator.' },
  { id: 'wo3', workOrderNumber: 'WO-003', title: 'Network cabinet audit', customerId: 'c3', siteId: 's3', technicianId: 't3', status: 'IN_PROGRESS', priority: 'MEDIUM', createdAt: '2026-07-22', scheduledDate: '2026-07-25', updatedAt: '2026-07-22', description: 'Audit network cabinets and replace failing sensors.' },
  { id: 'wo4', workOrderNumber: 'WO-004', title: 'Access panel replacement', customerId: 'c1', siteId: 's1', technicianId: 't4', status: 'COMPLETED', priority: 'LOW', createdAt: '2026-07-21', scheduledDate: '2026-07-22', updatedAt: '2026-07-21', description: 'Replace worn access panel and verify secure closure.' },
];

export const notifications: NotificationItem[] = [
  { id: 'n1', title: 'Work order updated', message: 'HVAC optimization moved to assigned', time: '10 mins ago', read: false },
  { id: 'n2', title: 'Technician check-in', message: 'Jonas checked in at Apex Substation', time: '32 mins ago', read: true },
  { id: 'n3', title: 'Customer follow-up', message: 'BluePeak requested a revised service window', time: '1 hr ago', read: false },
];

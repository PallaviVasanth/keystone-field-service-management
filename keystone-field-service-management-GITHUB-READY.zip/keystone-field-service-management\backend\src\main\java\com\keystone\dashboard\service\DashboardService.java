package com.keystone.dashboard.service;

import com.keystone.complaint.repository.ComplaintRepository;
import com.keystone.user.repository.UserRepository;
import com.keystone.workorder.repository.WorkOrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final WorkOrderRepository workOrderRepository;
    private final ComplaintRepository complaintRepository;
    private final UserRepository userRepository;

    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        
        // Work order stats
        stats.put("totalWorkOrders", workOrderRepository.count());
        stats.put("completedToday", workOrderRepository.countByCompletedDateToday());
        stats.put("activeTechnicians", userRepository.countByRole("TECHNICIAN"));
        
        // Complaint stats
        stats.put("pendingComplaints", complaintRepository.countByStatus("PENDING"));
        
        // Revenue (placeholder - would need actual invoice data)
        stats.put("revenue", 0);
        
        return stats;
    }
}
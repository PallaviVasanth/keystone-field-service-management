package com.keystone.complaint.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComplaintResponse {

    private UUID id;
    private UUID customerId;
    private String customerName;
    private String serviceType;
    private String description;
    private String priority;
    private String status;
    private UUID assignedTo;
    private String assignedToName;
    private String completionNotes;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime completedAt;
    private LocalDateTime customerConfirmedAt;
}
package com.keystone.workorder.repository;

import com.keystone.workorder.entity.WorkOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface WorkOrderRepository extends JpaRepository<WorkOrder, UUID> {

    Optional<WorkOrder> findByWorkOrderNumber(String workOrderNumber);

    boolean existsByWorkOrderNumber(String workOrderNumber);

    long countByCompletedDateBetween(LocalDateTime start, LocalDateTime end);

    default long countByCompletedDateToday() {
        LocalDateTime start = LocalDateTime.now().toLocalDate().atStartOfDay();
        LocalDateTime end = LocalDateTime.now().toLocalDate().plusDays(1).atStartOfDay();
        return countByCompletedDateBetween(start, end);
    }

    List<WorkOrder> findByTechnicianId(UUID technicianId);

    long countByTechnicianId(UUID technicianId);

    long countByTechnicianIdAndStatus(UUID technicianId, String status);

    long countByStatus(String status);

    long countByStatusIn(List<String> statuses);
}
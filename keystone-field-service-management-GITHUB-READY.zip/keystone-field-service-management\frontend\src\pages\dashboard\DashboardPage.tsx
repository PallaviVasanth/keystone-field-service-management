import { useState, useEffect } from 'react';
import { Box, Button, Card, CardContent, Grid, Stack, Typography, CircularProgress, Alert } from '@mui/material';
import { FiArrowRight, FiClipboard, FiUsers, FiTruck, FiAlertCircle } from 'react-icons/fi';
import { PageHeader } from '../../components/common/PageHeader';
import { StatCard } from '../../components/common/StatCard';
import { DataTable } from '../../components/common/DataTable';
import { StatusBadge } from '../../components/common/StatusBadge';
import { dashboardService, workOrderService } from '../../services/apiService';
import type { DashboardStats, WorkOrder } from '../../types';

export const DashboardPage = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [statsData, workOrdersData] = await Promise.all([
        dashboardService.getStats(),
        workOrderService.getAll(),
      ]);
      setStats(statsData);
      setWorkOrders(workOrdersData);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
      setError('Failed to load dashboard data');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      
      <Card sx={{ mb: 3, background: 'linear-gradient(135deg, #2563EB 0%, #3B82F6 45%, #60A5FA 100%)', color: 'white', border: 'none' }}>
        <CardContent sx={{ p: { xs: 3, md: 4 } }}>
          <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'flex-start', md: 'center' }} spacing={2}>
            <Box>
              <Typography variant="h5" fontWeight={800}>Command center</Typography>
              <Typography sx={{ mt: 1, opacity: 0.92 }}>Monitor field operations, dispatch flow, and service health from one vibrant workspace.</Typography>
            </Box>
            <Button variant="contained" sx={{ bgcolor: 'white', color: 'primary.main', '&:hover': { bgcolor: 'grey.100' } }} endIcon={<FiArrowRight />}>Create work order</Button>
          </Stack>
        </CardContent>
      </Card>
      <PageHeader title="Operations Overview" subtitle="A live pulse of service delivery and field productivity" badge="Live" />
      <Grid container spacing={3}>
        <Grid item xs={12} md={3}>
          <StatCard title="Work Orders" value={stats?.totalWorkOrders || 0} subtitle="Across all active regions" icon={<FiClipboard size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="Completed Today" value={stats?.completedToday || 0} subtitle="Ahead of SLA target" icon={<FiTruck size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="Active Technicians" value={stats?.activeTechnicians || 0} subtitle="Coverage in 3 zones" icon={<FiUsers size={20} />} />
        </Grid>
        <Grid item xs={12} md={3}>
          <StatCard title="Pending Complaints" value={stats?.pendingComplaints || 0} subtitle="Awaiting assignment" icon={<FiAlertCircle size={20} />} />
        </Grid>
      </Grid>
      <Grid container spacing={3} sx={{ mt: 0.5 }}>
        <Grid item xs={12} lg={8}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>Recent work orders</Typography>
              <DataTable rows={workOrders.slice(0, 4)} columns={[
                { key: 'workOrderNumber', label: 'WO #' },
                { key: 'title', label: 'Title' },
                { key: 'priority', label: 'Priority' },
                { key: 'status', label: 'Status', render: (row) => <StatusBadge label={row.status} color={row.status === 'COMPLETED' ? 'success' : row.status === 'PENDING' ? 'warning' : 'primary'} /> },
              ]} />
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} lg={4}>
          <Card>
            <CardContent>
              <Typography variant="h6" fontWeight={700} sx={{ mb: 2 }}>System Status</Typography>
              <Stack spacing={2}>
                <Box sx={{ p: 2, borderRadius: 2, bgcolor: 'success.light', color: 'success.dark' }}>
                  <Typography fontWeight={700}>All Systems Operational</Typography>
                  <Typography variant="body2">Last checked: Just now</Typography>
                </Box>
                <Box sx={{ p: 2, borderRadius: 2, bgcolor: 'info.light', color: 'info.dark' }}>
                  <Typography fontWeight={700}>Database Connected</Typography>
                  <Typography variant="body2">H2 in-memory database active</Typography>
                </Box>
              </Stack>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

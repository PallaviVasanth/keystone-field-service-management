package com.keystone.complaint.service;

import com.keystone.complaint.dto.ComplaintResponse;
import com.keystone.complaint.dto.CreateComplaintRequest;
import com.keystone.complaint.dto.UpdateComplaintRequest;
import com.keystone.complaint.entity.Complaint;
import com.keystone.complaint.repository.ComplaintRepository;
import com.keystone.user.entity.User;
import com.keystone.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final UserRepository userRepository;

    public ComplaintResponse createComplaint(CreateComplaintRequest request) {
        User customer = userRepository.findById(request.getCustomerId())
                .orElseThrow(() -> new IllegalArgumentException("Customer not found"));

        Complaint complaint = Complaint.builder()
                .customer(customer)
                .serviceType(request.getServiceType())
                .description(request.getDescription())
                .priority(request.getPriority())
                .status("PENDING")
                .build();

        Complaint savedComplaint = complaintRepository.save(complaint);
        return mapToResponse(savedComplaint);
    }

    public List<ComplaintResponse> getAllComplaints() {
        return complaintRepository.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public ComplaintResponse getComplaintById(UUID id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Complaint not found"));
        return mapToResponse(complaint);
    }

    public List<ComplaintResponse> getComplaintsByCustomer(UUID customerId) {
        return complaintRepository.findByCustomerId(customerId).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public List<ComplaintResponse> getComplaintsByAssignedTo(UUID assignedTo) {
        User user = userRepository.findById(assignedTo)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        return complaintRepository.findByAssignedTo(user).stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    public ComplaintResponse updateComplaint(UUID id, UpdateComplaintRequest request) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Complaint not found"));

        if (request.getServiceType() != null) {
            complaint.setServiceType(request.getServiceType());
        }
        if (request.getDescription() != null) {
            complaint.setDescription(request.getDescription());
        }
        if (request.getPriority() != null) {
            complaint.setPriority(request.getPriority());
        }
        if (request.getStatus() != null) {
            complaint.setStatus(request.getStatus());
            
            // Set completion timestamp when status is RESOLVED
            if ("RESOLVED".equals(request.getStatus()) && complaint.getCompletedAt() == null) {
                complaint.setCompletedAt(LocalDateTime.now());
            }
        }
        if (request.getAssignedTo() != null) {
            User assignedTo = userRepository.findById(request.getAssignedTo())
                    .orElseThrow(() -> new IllegalArgumentException("Assigned user not found"));
            complaint.setAssignedTo(assignedTo);
            
            // Update status to ASSIGNED when a technician is assigned
            if (complaint.getStatus().equals("PENDING")) {
                complaint.setStatus("ASSIGNED");
            }
        }
        if (request.getCompletionNotes() != null) {
            complaint.setCompletionNotes(request.getCompletionNotes());
        }

        Complaint savedComplaint = complaintRepository.save(complaint);
        return mapToResponse(savedComplaint);
    }

    public ComplaintResponse confirmCompletion(UUID id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Complaint not found"));

        if (!"RESOLVED".equals(complaint.getStatus())) {
            throw new IllegalStateException("Complaint must be resolved before customer confirmation");
        }

        complaint.setStatus("CUSTOMER_CONFIRMED");
        complaint.setCustomerConfirmedAt(LocalDateTime.now());

        Complaint savedComplaint = complaintRepository.save(complaint);
        return mapToResponse(savedComplaint);
    }

    public void deleteComplaint(UUID id) {
        Complaint complaint = complaintRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Complaint not found"));
        complaintRepository.delete(complaint);
    }

    private ComplaintResponse mapToResponse(Complaint complaint) {
        return ComplaintResponse.builder()
                .id(complaint.getId())
                .customerId(complaint.getCustomer().getId())
                .customerName(complaint.getCustomer().getFirstName() + " " + complaint.getCustomer().getLastName())
                .serviceType(complaint.getServiceType())
                .description(complaint.getDescription())
                .priority(complaint.getPriority())
                .status(complaint.getStatus())
                .assignedTo(complaint.getAssignedTo() != null ? complaint.getAssignedTo().getId() : null)
                .assignedToName(complaint.getAssignedTo() != null ? 
                        complaint.getAssignedTo().getFirstName() + " " + complaint.getAssignedTo().getLastName() : null)
                .completionNotes(complaint.getCompletionNotes())
                .createdAt(complaint.getCreatedAt())
                .updatedAt(complaint.getUpdatedAt())
                .completedAt(complaint.getCompletedAt())
                .customerConfirmedAt(complaint.getCustomerConfirmedAt())
                .build();
    }
}
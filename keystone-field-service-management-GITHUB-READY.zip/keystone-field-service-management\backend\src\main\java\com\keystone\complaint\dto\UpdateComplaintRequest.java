package com.keystone.complaint.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateComplaintRequest {

    private String serviceType;

    private String description;

    private String priority;

    @NotNull
    private String status;

    private UUID assignedTo;

    private String completionNotes;
}
-- ============================================================================
-- V7__create_complaints_table.sql
--
-- Creates the "complaints" table for customer service complaints
-- ============================================================================
CREATE TABLE complaints (
    id UUID PRIMARY KEY,
    customer_id UUID NOT NULL,
    service_type VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    priority VARCHAR(20) NOT NULL,
    status VARCHAR(20) NOT NULL,
    assigned_to UUID,
    completion_notes TEXT,
    created_at TIMESTAMP NOT NULL,
    updated_at TIMESTAMP NOT NULL,
    completed_at TIMESTAMP,
    customer_confirmed_at TIMESTAMP,

    CONSTRAINT fk_complaint_customer
        FOREIGN KEY (customer_id)
        REFERENCES users(id),

    CONSTRAINT fk_complaint_assigned_to
        FOREIGN KEY (assigned_to)
        REFERENCES users(id)
);
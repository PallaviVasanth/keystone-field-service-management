import { createContext, useContext, useMemo, useState, useEffect, type ReactNode } from 'react';
import type { User, UserRole, LoginRequest } from '../types';
import { authService } from '../services/apiService';

interface AuthContextValue {
  user: User | null;
  role: UserRole;
  isLoading: boolean;
  login: (credentials: LoginRequest) => Promise<void>;
  logout: () => void;
}

// Demo users for testing without backend
const demoUsers: Record<string, User> = {
  'admin@keystone.com': {
    id: 'demo-admin',
    firstName: 'Admin',
    lastName: 'User',
    email: 'admin@keystone.com',
    role: 'ADMIN',
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  'manager@keystone.com': {
    id: 'demo-manager',
    firstName: 'Manager',
    lastName: 'User',
    email: 'manager@keystone.com',
    role: 'MANAGER',
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  'dispatcher@keystone.com': {
    id: 'demo-dispatcher',
    firstName: 'Dispatcher',
    lastName: 'User',
    email: 'dispatcher@keystone.com',
    role: 'DISPATCHER',
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  'technician@keystone.com': {
    id: 'demo-technician',
    firstName: 'John',
    lastName: 'Technician',
    email: 'technician@keystone.com',
    role: 'TECHNICIAN',
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  'worker@keystone.com': {
    id: 'demo-worker',
    firstName: 'Jane',
    lastName: 'Worker',
    email: 'worker@keystone.com',
    role: 'WORKER',
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  'customer@keystone.com': {
    id: 'demo-customer',
    firstName: 'Customer',
    lastName: 'One',
    email: 'customer@keystone.com',
    role: 'CUSTOMER',
    active: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing token and user data on mount
    const token = localStorage.getItem('keystone-token');
    const storedUser = localStorage.getItem('keystone-user');
    
    if (token && storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        localStorage.removeItem('keystone-token');
        localStorage.removeItem('keystone-user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (credentials: LoginRequest) => {
    try {
      // Try backend login first
      const response = await authService.login(credentials);
      
      const userData: User = {
        id: response.userId,
        firstName: response.firstName,
        lastName: response.lastName,
        email: response.email,
        role: response.role,
        active: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      localStorage.setItem('keystone-token', response.token);
      localStorage.setItem('keystone-user', JSON.stringify(userData));
      setUser(userData);
    } catch (error) {
      // Fallback to demo mode if backend is not available
      console.log('Backend not available, using demo mode');
      const demoUser = demoUsers[credentials.email];
      
      if (demoUser && credentials.password === 'password123') {
        localStorage.setItem('keystone-user', JSON.stringify(demoUser));
        setUser(demoUser);
      } else {
        throw new Error('Invalid credentials. Use demo accounts with password: password123');
      }
    }
  };

  const logout = () => {
    authService.logout();
    setUser(null);
  };

  const role = user?.role ?? 'CUSTOMER';

  const value = useMemo(() => ({ user, role, isLoading, login, logout }), [user, role, isLoading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

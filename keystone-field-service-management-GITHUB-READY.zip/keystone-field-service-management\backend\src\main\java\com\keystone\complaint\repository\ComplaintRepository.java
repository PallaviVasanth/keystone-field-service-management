package com.keystone.complaint.repository;

import com.keystone.complaint.entity.Complaint;
import com.keystone.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, UUID> {

    List<Complaint> findByCustomerId(UUID customerId);

    List<Complaint> findByAssignedTo(User assignedTo);

    List<Complaint> findByStatus(String status);

    long countByCustomerId(UUID customerId);

    long countByCustomerIdAndStatus(UUID customerId, String status);

    long countByStatus(String status);
}